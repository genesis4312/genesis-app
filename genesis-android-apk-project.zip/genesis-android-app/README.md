# Genesis Downloader — Android APK project

This is a native Android WebView shell with a custom orange-and-black **G** launcher icon. It opens the Genesis web app in a standalone Android app window.

## Important before building

1. Deploy the included `web-project.zip` contents to Netlify first (or make sure the current site already contains the updated app and Netlify Functions).
2. If you deploy to a different Netlify URL, edit `app/src/main/java/com/genesis/downloader/MainActivity.kt` and change `appUrl`.
3. Add `YOUTUBE_API_KEY` in the Netlify site's environment variables for Google's YouTube Data API v3 primary search. The backend falls back to Invidious when Google is not configured or fails. Do not put the key in Android source code.

## Build an APK using only your phone

1. Create a GitHub repository and upload all files/folders in this project.
2. Open the repository's **Actions** tab.
3. Select **Build Genesis Android APK** and tap **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `Genesis-Downloader-APK` artifact.
5. Extract the artifact ZIP; it contains `app-debug.apk`. Install it on Android and allow installation from your browser/files app if prompted.

The generated APK is a debug APK for testing/sideloading. A Play Store release needs a separately signed release build.

## What this APK is

The APK is a native Android launcher/container, while the downloader interface and API backend are hosted by your Netlify website. An internet connection is required for search/download functions. This does not create a fully offline downloader or publish to Google Play.
