package com.genesis.downloader

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.graphics.Color
import android.view.Gravity
import android.webkit.DownloadListener

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar

    // Deploy the included Netlify web-project first, then replace this URL if you use a new site.
    private val appUrl = "https://tiktok-video-fetcher.netlify.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 8, 14)
        window.navigationBarColor = Color.rgb(8, 8, 14)
        window.decorView.systemUiVisibility = 0

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(8, 8, 14)) }
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 125, 45))
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 125, 45))
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress, FrameLayout.LayoutParams(-1, 5, Gravity.TOP))
        setContentView(root)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.settings.setSupportZoom(false)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return if (uri.host == "tiktok-video-fetcher.netlify.app" || uri.host?.endsWith("netlify.app") == true) {
                    false
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                }
            }
            override fun onPageFinished(view: WebView, url: String?) { progress.visibility = View.GONE }
        }
        webView.webChromeClient = WebChromeClient()
        webView.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            try { startActivity(intent) } catch (_: Exception) { }
        })
        if (savedInstanceState == null) webView.loadUrl(appUrl) else webView.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
